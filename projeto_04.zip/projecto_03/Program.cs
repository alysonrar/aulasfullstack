﻿// // See https://aka.ms/new-console-template for more information
// int inteiro = 10;
// Double pontodecimal= 49.99;
// bool bolleano=true;
// Console.WriteLine($"Interio:{inteiro}");
// Console.WriteLine($"Doube: {pontodecimal}");
// Console.WriteLine($"Bool: {bolleano}");

// Console.WriteLine($"3>4: {3>4}");
// Console.WriteLine($"3<4: {3<4}");
// Console.WriteLine($"3>=4: {3>=4}");
// Console.WriteLine($"3<=4: {3<=4}");
// Console.WriteLine($"3==4: {3==4}");
// Console.WriteLine($"3!=4: {3!=4}");

//&& e
Console.WriteLine($"{(3<4) && (5==5) }");
//|| ou
Console.WriteLine($"{(3<4) || (5==5) }");
// ! não
Console.WriteLine($"{!(3==3) }");