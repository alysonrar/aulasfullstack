﻿// See https://aka.ms/new-console-template for more information
// using System.Globalization;

// Console.Write("Digite as horas:");
// int horas = int.Parse(Console.ReadLine());
// if(horas < 12){
//     Console.Write("Bom Dia");
// }
// if(horas >=12 && horas < 18){
//     Console.Write("Boa tarde");
// }
// if(horas>=18 && horas <=24){
//     Console.WriteLine("Boa noite");

// }

Console.Write("Digite seu sexo: ");

// else if (sexo == 'f' || sexo == 'F'){
//     Console.WriteLine("Você é uma mulher.");}
// else {
//     Console.WriteLine("Opção invalida");
// }
// Console.WriteLine("\n Progama finalizado");

char sexo = char.Parse(Console.ReadLine());
int idade = 0;
if (sexo == 'm' || sexo == 'M')
{
    Console.WriteLine("Você é um homem.");

    Console.WriteLine("Digite sua idade: ");
    idade = int.Parse(Console.ReadLine());
    if (idade < 18)
    {

        Console.WriteLine("Você menor de idade.");
    }
    else if (idade >= 18)
    {
        Console.WriteLine("Você é maior de idade.");
    }
}



if (sexo == 'F' || sexo == 'f')
{
    Console.WriteLine("Você é uma mulher.");

    Console.WriteLine("Digite sua idade: ");
    idade = int.Parse(Console.ReadLine());
    if (idade < 18)
    {

        Console.WriteLine("Você menor de idade.");
    }
    else if (idade >= 18)
    {
        Console.WriteLine("Você é maior de idade.");
    }

    Console.WriteLine("\n Progama finalizado");

}
