﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
bool valA, valB;
Console.WriteLine("TABELA VERDADE || (ou , or)");
valA= true;
valB=true;
Console.WriteLine($"V  ||  V = {valA || valB}");

valA= true;
valB=false;
Console.WriteLine($"V  ||  F = {valA || valB}");

valA= false;
valB=true;
Console.WriteLine($"F  ||  V = {valA || valB}");

valA= false;
valB=false;
Console.WriteLine($"F  ||  F = {valA || valB}");  